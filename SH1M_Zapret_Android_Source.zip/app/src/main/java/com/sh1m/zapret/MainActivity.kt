package com.sh1m.zapret

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(15, 16, 18)
    private val panel = Color.rgb(27, 29, 33)
    private val text = Color.rgb(242, 243, 245)
    private val muted = Color.rgb(164, 169, 177)
    private val accent = Color.rgb(205, 48, 56)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.setBackgroundColor(bg)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(26), dp(22), dp(24))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply { addView(page) }

        page.addView(label("SH1M", 13, accent, true))
        page.addView(label("ZAPRET", 32, text, true))
        page.addView(label("Android 15 · preview", 14, muted, false))
        page.addView(space(24))

        val statusCard = card()
        statusCard.addView(label("СОСТОЯНИЕ", 12, muted, true))
        statusCard.addView(label("Сетевой движок не подключён", 18, text, true))
        statusCard.addView(label(
            "Это предварительная оболочка. Обход DPI пока не работает: Windows winws.exe и WinDivert не запускаются на Android.",
            14, muted, false
        ))
        page.addView(statusCard)
        page.addView(space(18))

        page.addView(label("ПРИЛОЖЕНИЯ", 12, muted, true))
        val discord = CheckBox(this).apply {
            text = "Discord"
            setTextColor(text)
            isChecked = true
            buttonTintList = android.content.res.ColorStateList.valueOf(accent)
        }
        val youtube = CheckBox(this).apply {
            text = "YouTube"
            setTextColor(text)
            isChecked = true
            buttonTintList = android.content.res.ColorStateList.valueOf(accent)
        }
        page.addView(discord)
        page.addView(youtube)
        page.addView(space(12))

        page.addView(label("СТРАТЕГИЯ", 12, muted, true))
        page.addView(label("Источник: zapret-discord-youtube 1.9.2", 15, text, false))
        page.addView(label(
            "Параметры Windows-стратегий показаны только как ориентир. Для Android нужен совместимый движок.",
            13, muted, false
        ))
        page.addView(space(20))

        val button = Button(this).apply {
            text = "ПОДКЛЮЧИТЬ — ПОКА НЕДОСТУПНО"
            isEnabled = false
            setTextColor(Color.WHITE)
            setBackgroundColor(panel)
        }
        page.addView(button, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(54)
        ))
        page.addView(space(18))

        val footer = label(
            "SH1M Zapret Preview • Без root • Не создаёт VPN и не изменяет трафик",
            12, muted, false
        )
        page.addView(footer)
        setContentView(scroll)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setBackgroundColor(panel)
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.bottomMargin = dp(4)
        layoutParams = lp
    }

    private fun label(value: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(3), 0, dp(5))
        }

    private fun space(h: Int) = android.view.View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(h))
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
