plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.sh1m.zapret"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.sh1m.zapret"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-preview"
    }
}
